// student_dashboard_page.dart
import 'package:flutter/material.dart';
import 'progress_page.dart';
import 'package:fl_chart/fl_chart.dart';
import 'attendance_report_page.dart';
import 'results_button_page.dart';
import 'fees_details_page.dart';
import 'ecab_page.dart';

class StudentDashboardPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Student Dashboard',
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              // Handle menu item selection
              print('Selected menu item: $value');
            },
            itemBuilder: (BuildContext context) => [
              PopupMenuItem<String>(
                value: 'session_bar',
                child: Text('Session Bar'),
              ),
              PopupMenuItem<String>(
                value: 'queries',
                child: Text('Queries'),
              ),
            ],
          ),
        ],
        backgroundColor:
            Colors.blue.shade900, // Set a dark blue color for the AppBar
      ),
      body: Column(
        children: [
          // Top Half
          Container(
            color: Colors
                .blue.shade800, // Set a different color for the top container
            padding: EdgeInsets.all(20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundImage:
                      AssetImage('assets/user_photo_placeholder.jpeg'),
                ),
                SizedBox(width: 20),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'User Name',
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                    Text(
                      'ID Number: 123456',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                    Text(
                      'Branch: Computer Science',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Bottom Half
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 20.0,
                mainAxisSpacing: 20.0,
                children: [
                  DashboardSectionButton(
                    title: 'Progress',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ProgressPage(),
                        ),
                      );
                    },
                    color: Colors.indigo, // Set a new color for the button
                  ),
                  DashboardSectionButton(
                    title: 'Exam Results',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ResultsButtonPage(),
                        ),
                      );
                    },
                    color: Colors.green, // Set a new color for the button
                  ),
                  DashboardSectionButton(
                    title: 'Attendance Report',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AttendanceReportPage(),
                        ),
                      );
                    },
                    color: Colors.deepOrange, // Set a new color for the button
                  ),
                  DashboardSectionButton(
                    title: 'E-CAB',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ECABPage(),
                        ),
                      );
                    },
                    color: Colors.teal, // Set a new color for the button
                  ),
                  DashboardSectionButton(
                    title: 'Fees',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => FeesDetailsPage(),
                        ),
                      );
                    },
                    color: Colors.purple, // Set a new color for the button
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class DashboardSectionButton extends StatelessWidget {
  final String title;
  final VoidCallback? onPressed;
  final Color? color;

  DashboardSectionButton({required this.title, this.onPressed, this.color});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        primary: color ?? Theme.of(context).colorScheme.secondary,
        padding: EdgeInsets.all(20),
        minimumSize: Size(150, 150),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        elevation: 5,
      ),
      child: Text(
        title,
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }
}
