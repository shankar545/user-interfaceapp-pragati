// fees_details_page.dart
import 'package:flutter/material.dart';

class FeesDetailsPage extends StatelessWidget {
  // Placeholder data, replace with actual data
  final double collegeFees = 5000;
  final double busFees = 1000;
  final double crtFees = 2000;
  final double collegeFeesPaid = 3500;
  final double busFeesPaid = 800;
  final double crtFeesPaid = 1500;

  @override
  Widget build(BuildContext context) {
    // Calculate remaining balances
    final double collegeFeesRemaining = collegeFees - collegeFeesPaid;
    final double busFeesRemaining = busFees - busFeesPaid;
    final double crtFeesRemaining = crtFees - crtFeesPaid;

    // Calculate overall totals
    final double overallTotal = collegeFees + busFees + crtFees;
    final double totalPaid = collegeFeesPaid + busFeesPaid + crtFeesPaid;
    final double totalBalance = overallTotal - totalPaid;

    return Scaffold(
      appBar: AppBar(
        title: Text('Fees Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          // Wrap with SingleChildScrollView
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              FeeDetailRow('College Fees', collegeFees, collegeFeesPaid,
                  collegeFeesRemaining),
              FeeDetailRow('Bus Fees', busFees, busFeesPaid, busFeesRemaining),
              FeeDetailRow('CRT Fees', crtFees, crtFeesPaid, crtFeesRemaining),
              Divider(),
              TotalRow('Overall Total', overallTotal),
              TotalRow('Total Paid', totalPaid),
              TotalRow('Total Balance', totalBalance),
            ],
          ),
        ),
      ),
    );
  }
}

class FeeDetailRow extends StatelessWidget {
  final String label;
  final double totalAmount;
  final double paidAmount;
  final double remainingAmount;

  FeeDetailRow(
      this.label, this.totalAmount, this.paidAmount, this.remainingAmount);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 1,
            blurRadius: 3,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '₹$totalAmount',
                style: TextStyle(fontSize: 16),
              ),
              Text(
                'Paid: ₹$paidAmount',
                style: TextStyle(fontSize: 14, color: Colors.green),
              ),
              Text(
                'Remaining: ₹$remainingAmount',
                style: TextStyle(fontSize: 14, color: Colors.red),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class TotalRow extends StatelessWidget {
  final String label;
  final double totalAmount;

  TotalRow(this.label, this.totalAmount);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 1,
            blurRadius: 3,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
          ),
          Text(
            '₹$totalAmount',
            style: TextStyle(fontSize: 16, color: Colors.white),
          ),
        ],
      ),
    );
  }
}
