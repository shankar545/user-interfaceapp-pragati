// assignment_page.dart
import 'package:flutter/material.dart';

class AssignmentPage extends StatefulWidget {
  @override
  _AssignmentPageState createState() => _AssignmentPageState();
}

class _AssignmentPageState extends State<AssignmentPage> {
  TextEditingController classNameController = TextEditingController();
  TextEditingController assignmentNumberController = TextEditingController();
  TextEditingController numbersController = TextEditingController();

  List<int> enteredNumbers = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Assignments'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: classNameController,
              decoration: InputDecoration(
                labelText: 'Enter Class Name',
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: assignmentNumberController,
              decoration: InputDecoration(
                labelText: 'Enter Assignment Number',
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: numbersController,
              decoration: InputDecoration(
                labelText: 'Enter Numbers',
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                // Extract entered numbers from the input text
                List<int> numbers = numbersController.text
                    .split(',')
                    .map((e) => int.tryParse(e) ?? 0)
                    .toList();

                // Sort the numbers
                numbers.sort();

                setState(() {
                  enteredNumbers = numbers;
                });
              },
              child: Text('Submit'),
            ),
            SizedBox(height: 16),
            Text(
              'Entered Numbers (Sorted): ${enteredNumbers.join(', ')}',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
