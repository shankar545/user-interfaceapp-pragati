import 'package:flutter/material.dart';

class StudentEcabPage extends StatefulWidget {
  @override
  _StudentEcabPageState createState() => _StudentEcabPageState();
}

class _StudentEcabPageState extends State<StudentEcabPage> {
  TextEditingController searchTextController = TextEditingController();
  TextEditingController messageController = TextEditingController();

  Map<String, List<String>> studentMessages = {};
  String selectedStudentId = "";
  String selectedStudentDetails = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Student E-CAB'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: searchTextController,
              decoration: InputDecoration(
                labelText: 'Search by ID or Name',
              ),
              enabled: true, // Ensure the text field is enabled
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () async {
                // Perform search logic here based on the entered text
                // For simplicity, just set the selectedStudentId to a placeholder value
                String searchedId = '123456';
                setState(() {
                  selectedStudentId = searchedId;
                });

                // Retrieve or initialize messages for the selected student
                if (ModalRoute.of(context)?.settings.arguments != null) {
                  Map<String, List<String>>? messages = ModalRoute.of(context)
                      ?.settings
                      .arguments as Map<String, List<String>>?;
                  if (messages != null &&
                      messages.containsKey(selectedStudentId)) {
                    studentMessages = messages;
                  }
                }

                // Retrieve student details based on the selected ID
                String studentDetails =
                    await getStudentDetails(selectedStudentId);
                setState(() {
                  selectedStudentDetails = studentDetails;
                });
              },
              child: Text('Search'),
            ),
            SizedBox(height: 16),
            if (selectedStudentId.isNotEmpty)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Selected Student ID: $selectedStudentId',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 16),
                  if (selectedStudentDetails.isNotEmpty)
                    Text(
                      'Student Details: $selectedStudentDetails',
                      style: TextStyle(fontSize: 16),
                    ),
                  SizedBox(height: 16),
                  TextField(
                    controller: messageController,
                    decoration: InputDecoration(
                      labelText: 'Enter your message',
                    ),
                  ),
                  SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      // Save the entered message for the selected student
                      setState(() {
                        String message = messageController.text;
                        studentMessages
                            .putIfAbsent(selectedStudentId, () => [])
                            .add(message);
                      });
                      messageController
                          .clear(); // Clear the text field after submission
                    },
                    child: Text('Submit'),
                  ),
                  SizedBox(height: 16),
                  if (studentMessages.containsKey(selectedStudentId))
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Messages for $selectedStudentId:',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        for (String message
                            in studentMessages[selectedStudentId]!)
                          Text(
                            '- $message',
                            style: TextStyle(fontSize: 16),
                          ),
                      ],
                    ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Future<String> getStudentDetails(String studentId) async {
    // Implement the logic to retrieve student details based on the ID
    // For example, you can use Firebase Firestore or another data source
    // For now, returning a placeholder value
    return 'Student Name: John Doe\nClass: 4th- CSE-A\nDisciplinary Activities: ...';
  }
}
