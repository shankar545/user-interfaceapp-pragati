// progress_page.dart
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class ProgressPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Progress Page'),
      ),
      body: Center(
        child: LineChartSample1(),
      ),
    );
  }
}

class LineChartSample1 extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => LineChartSample1State();
}

class LineChartSample1State extends State<LineChartSample1> {
  @override
  Widget build(BuildContext context) {
    return LineChart(
      lineChartData(),
    );
  }

  LineChartData lineChartData() {
    return LineChartData(
      gridData: FlGridData(
        show: true,
        drawHorizontalLine: true,
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xff37434d),
            strokeWidth: 1,
          );
        },
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xff37434d),
            strokeWidth: 1,
          );
        },
      ),
      titlesData: FlTitlesData(
        leftTitles: SideTitles(
          showTitles: true,
        ),
        bottomTitles: SideTitles(
          showTitles: true,
          reservedSize: 22,
        ),
      ),
      borderData: FlBorderData(
        show: true,
        border: Border.all(
          color: const Color(0xff37434d),
          width: 1,
        ),
      ),
      minX: 1,
      maxX: 8,
      minY: 1,
      maxY: 10,
      lineBarsData: [
        LineChartBarData(
          spots: [
            FlSpot(1, 9),
            FlSpot(2, 8.5),
            FlSpot(3, 8),
            FlSpot(4, 8),
            // Add more data points as needed
          ],
          isCurved: true,
          colors: [Colors.blue],
          barWidth: 4,
          belowBarData: BarAreaData(show: false),
        ),
      ],
    );
  }
}
