// ecab_page.dart
import 'package:flutter/material.dart';

class ECABPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('E-CAB Page'),
      ),
      body: ECABDetails(),
    );
  }
}

class ECABDetails extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.all(16),
      children: [
        DisciplinaryActionCard(
          date: '2023-11-15',
          time: '14:30',
          action: 'Late to class',
        ),
        DisciplinaryActionCard(
          date: '2023-11-16',
          time: '09:45',
          action: 'Talking during lecture',
        ),
        // Add more DisciplinaryActionCard widgets as needed
      ],
    );
  }
}

class DisciplinaryActionCard extends StatelessWidget {
  final String date;
  final String time;
  final String action;

  DisciplinaryActionCard({
    required this.date,
    required this.time,
    required this.action,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Date: $date',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Time: $time',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Action: $action',
              style: TextStyle(
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
