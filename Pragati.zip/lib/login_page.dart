import 'package:flutter/material.dart';
import 'student_dashboard_page.dart';
import 'teacher_dashboard_page.dart';

class LoginPage extends StatelessWidget {
  final String role;

  LoginPage({required this.role});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '$role Login',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // "PRAGATI" logo and Engineering College (Autonomous) name
          Hero(
            tag: 'pragatiLogo',
            child: Material(
              color: Colors.transparent,
              child: Column(
                children: [
                  SizedBox(height: 20),
                  Text(
                    'PRAGATI',
                    style: TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue.shade800,
                    ),
                  ),
                  Text(
                    'Engineering College (Autonomous)',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                    ),
                  ),
                  SizedBox(height: 20),
                ],
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Enter your ID',
                fillColor: Colors.white,
                filled: true,
              ),
            ),
          ),
          SizedBox(height: 20),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Enter your password',
                fillColor: Colors.white,
                filled: true,
              ),
              obscureText: true,
            ),
          ),
          SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                onPressed: () {
                  // Handle forgot password
                  print('Forgot Password');
                },
                child: Text(
                  'Forgot Password?',
                  style: TextStyle(color: Colors.blue),
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              // Handle login button press based on role
              // You can navigate to different pages based on the role
              // For now, just print a message based on the role
              print('$role logged in');
              if (role == 'Student') {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => StudentDashboardPage(),
                  ),
                );
              } else if (role == 'Teacher') {
                print('Navigating to Teacher Dashboard');
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TeacherDashboardPage(
                        teacherName:
                            'John Doe'), // Replace with actual teacher name
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              primary: Theme.of(context).colorScheme.secondary!,
              padding: EdgeInsets.all(16),
            ),
            child: Text('Login'),
          ),
        ],
      ),
    );
  }
}
