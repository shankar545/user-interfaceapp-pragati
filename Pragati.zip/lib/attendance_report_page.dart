// attendance_report_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AttendanceReportPage extends StatefulWidget {
  @override
  _AttendanceReportPageState createState() => _AttendanceReportPageState();
}

class _AttendanceReportPageState extends State<AttendanceReportPage> {
  TextEditingController attendedDaysController = TextEditingController();
  TextEditingController totalDaysController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Attendance Report Page'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: attendedDaysController,
              keyboardType: TextInputType.number,
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.digitsOnly,
              ],
              decoration: InputDecoration(labelText: 'Attended Days'),
            ),
            SizedBox(height: 16),
            TextField(
              controller: totalDaysController,
              keyboardType: TextInputType.number,
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.digitsOnly,
              ],
              decoration: InputDecoration(labelText: 'Total Days'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                int attendedDays = int.parse(attendedDaysController.text);
                int totalDays = int.parse(totalDaysController.text);

                double attendancePercentage = (attendedDays / totalDays) * 100;

                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text('Attendance Result'),
                    content:
                        Text('Attendance Percentage: $attendancePercentage%'),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('OK'),
                      ),
                    ],
                  ),
                );
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
