package com.example.pragati

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
